<template>
  <van-contact-card
    type="edit"
    name="张三"
    tel="13000000000"
    :editable="false"
  />
</template>

<script>
	export default {
		name: "UserTake"
	}
</script>

<style scoped>

</style>