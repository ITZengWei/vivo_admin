import Vue from 'vue'
import App from './App.vue'

/* 引入 router 模快 */
import router from './router'

/* 引入 vant 框架 */
/* 暂时全局导入 */
import Vant from 'vant';
import 'vant/lib/index.css';

/* 引入数据 */
import tempData from './Mock/mock'

Vue.use(Vant)

/* 引入所有基础组件 */
import BaseCmp from './components'
Vue.use(BaseCmp)

/* 是否为上线 */
Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
