/* 模拟数据 */
/* 引入mock */
import Mock  from 'mockjs'

const Random = Mock.Random

/* 随机函数 */
function rand(num, callback) {
	const arr = []
	for (let i = 0; i < num; i++) {
		arr.push(callback)
	}
	return arr
}

/* 轮播图 图片 */
const CarouselImages = [
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/20180418/20180418104131830678_original.jpg',
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/20180430/20180430232146894398_original.jpg',
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/20180418/20180418104131830678_original.jpg'
]
/* 商品列表 */
/*const ProductList = [
	{
		src: 'https://shopstatic.vivo.com.cn/vivoshop/commodity/71/4171_1496689409434hd_530x530.png',
		title: 'X9Plus全网通',
		ad: '花呗免息，0首付0利率轻松购机',
	}

	'https://shopstatic.vivo.com.cn/vivoshop/commodity/71/4171_1496689409434hd_530x530.png',
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/40/4440_1508723830538hd_530x530.png',
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/95/4495_1509454710945hd_530x530.png',
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/66/4266_1496689781362hd_530x530.png',
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/11/4111_1492998667334hd_530x530.png',
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/80/4180_1496689544465hd_530x530.png',
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/27/5027_1526972514378hd_250x250.png',
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/20/4020_1481558694236_530x530.png',
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/82/1882_1481558960471_530x530.png',
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/73/4273_1491007460873hd_250x250.png',
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/83/4183_1482921083765_530x530.png',
	'https://shopstatic.vivo.com.cn/vivoshop/commodity/81/4181_1482720908043_250x250.png'
]*/

/* 首页数据 */
const data = Mock.mock({
	carousel: [
		CarouselImages
	],
	product: {
		main: {
			// 'src|1': ProductImages
		}
	}
})

Mock.mock('/api/data', 'get', data)

